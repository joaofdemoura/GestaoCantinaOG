# Layout Cantina OG para Figma

Cinco telas feitas com as seis fotos originais de Alimentos.zip: início, cardápio, produto, carrinho e login dos responsáveis.

## Opção rápida
Abra um arquivo de design no Figma e arraste os arquivos tela-1.svg a tela-5.svg para o canvas. As fotos estão incorporadas nos SVGs; nenhum download externo é necessário.

## Camadas nativas do Figma
1. Extraia este ZIP.
2. Abra o Figma Desktop e um arquivo de design.
3. Em Plugins > Development > Import plugin from manifest, selecione manifest.json.
4. Execute Cantina OG • Importar layout no menu de plugins de desenvolvimento.

O importador cria uma nova página com cinco frames de 390 × 844 px, textos Inter, retângulos e imagens com preenchimento. Não apaga nem modifica suas páginas existentes. Não acessa a internet.

As telas são uma proposta visual. Não contêm autenticação real, transações ou conexões de protótipo. A opção de recuperação de senha é uma proposta de interface e depende de implementação no app.

Pão de queijo R$ 5,00 e bolo R$ 7,00 vêm de web/api/banco.sql do ZIP enviado. Os outros quatro alimentos não possuem preço correspondente naquele catálogo e foram apresentados sem valores inventados. O carrinho de exemplo soma R$ 12,00.

Não foi criado um arquivo na sua conta Figma: a integração não foi ativada. O importador foi preparado e teve sua sintaxe verificada localmente; sua execução real no Figma depende da importação acima. Prévia e SVGs foram renderizados para revisão visual.
