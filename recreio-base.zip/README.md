# Recreio — painel de encomendas

Abra dist/index.html no navegador ou utilize um servidor estático local.

## Arquivos
- dist/index.html: estrutura do painel.
- dist/styles.css: cores, tipografia e layout.
- dist/app.js: dados fictícios, navegação, preparo e entrega.

## Escopo atual
Painel de encomendas, fila de retirada, preparo por intervalo, cardápio, alunos e responsáveis, histórico por aluno/mês e exportação CSV de pedidos. Não há criação manual de vendas ou pedidos, movimentações financeiras, saldo ou crédito. Preços permanecem somente no gerenciamento do cardápio.

O histórico utiliza diretamente os pedidos, não lançamentos de compras. O navegador migra a versão anterior, preservando encomendas e cadastros e removendo dados de transações, saldos e limites.

## Integração futura
Os pedidos ainda são fictícios, armazenados no localStorage. Não existe conexão com o app, autenticação ou banco compartilhado. Quando o app estiver disponível, substituir seed/carregamento/save por chamadas à API. Preservar os identificadores recebidos do app e sincronizar as ações de preparo/entrega no servidor.

Cada pedido utiliza id, student, date (AAAA-MM-DD), interval, status e items. Cada item utiliza id, name e qty. O app deverá fornecer os alunos relacionados e validar o acesso aos seus dados.

## Relatórios
A aba Relatórios substitui Configurações. Exibe pedidos, cliente, itens, intervalo, status e método de pagamento. O campo opcional `paymentMethod` de cada pedido é exibido quando fornecido pelo app; na ausência, aparece "Aguardando integração". Nenhum pagamento é inferido ou processado. Outros campos serão definidos posteriormente. A cor principal agora é vermelha, configurada por `--primary` no CSS.
